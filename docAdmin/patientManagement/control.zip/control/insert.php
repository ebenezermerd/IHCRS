<?php
require_once "class.php";
class insert extends DB_con
{

    function update($jk, $lkl, $LKl)
    {

    }


    // Generate a random patient ID
    function generatePatientID()
    {
        $characters = '0123456789';
        $idLength = 10;
        $patientID = '';
        for ($i = 0; $i < $idLength; $i++) {
            $randIndex = rand(0, strlen($characters) - 1);
            $patientID .= $characters[$randIndex];
        }
        return $patientID;
    }
    function generatePatientPass()
    {
        $characters = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ';
        $idLength = 16;
        $patientID = '';
        for ($i = 0; $i < $idLength; $i++) {
            $randIndex = rand(0, strlen($characters) - 1);
            $patientID .= $characters[$randIndex];
        }
        return $patientID;
    }


}
$insertion = new insert();
if (isset($_POST['patient_register'])) {
    // code to handle form submission
    $name = $_POST['name'];
    $sex = $_POST['sex'];
    $age = $_POST['Age'];
    $dob = $_POST['dob'];
    $regLoc = $_POST['regLoc'];
    $regDate = $_POST['regDate'];
    $city = $_POST['city'];
    $region = $_POST['Region'];
    $pnum = $_POST['pnum'];
    $email = $_POST['email'];
    $pass = $insertion->generatePatientPass();
    $p_id = $insertion->generatePatientID();
    $data = array(
        "patient_id" => $p_id,
        "full_name" => $name,
        "age" => $age,
        "sex" => $sex,
        "birth_date" => $dob,
        "location" => $regLoc,
        "date" => date('d/m/y'),
        "city" => $city,
        "region" => $region,
        "phone" => $pnum,
        "email" => $email,
        "password" => $pass
    );

    $x = $insertion->insert('patient', $data);
    if ($x)
        header("Location:../patient_rigister.php");
    else {
        echo "error";
    }
} ?>